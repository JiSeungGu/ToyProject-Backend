package com.example.projectdid.controller;

import com.google.bitcoin.core.AddressFormatException;
import org.json.simple.parser.ParseException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * packageName   : com.example.projectdid.controller
 * fileName  : DidController
 * author    : jiseung-gu
 * date  : 2023/01/18
 * description :
 **/
public class DidController {

    //    private final DidService didService;
//    private final RelayService relayService;
//
//    @PostMapping(value = "/verify")
//    public CommonResult verify(@RequestBody VerifyDto verifyDto) throws ParseException {
//        return relayService.vpVerify(verifyDto);
//    }


//    @PostMapping(value = "/verify")
//    public CommonResult verifiy(@RequestBody VerifyDto verifyDto) throws PrivateKey.BadKeyException, ParseException, AddressFormatException {
//
//
//        return relayService.Verify("VC",verifyDto);
            /** TODO
             *{
             *     "owner":"VC",
             *     "holderid" :"test",
             *     "vp" : "{\"@context\":[\"https://www.w3.org/2018/credentials/v1\"],\"id\":\"https://example.appnet.com/SejongAccessCredential/b3f7218f-26e0-4680-847c-23631c77543c\",\"type\":[\"VerifiableCredential\",\"SejongAccessCredential\"],\"credentialSubject\":[{\"type\":\"BlockChainDevelopment\",\"position\":\"GM\",\"name\":\"한현수\",\"phoneno\":\"01011112222\",\"status\":\"0\"}],\"issuer\":\"did:SEJONG_SCS:5uMrDKwrPtn3KipERYuDAhEmHyopnEMK9PRUQYVGv3EZ\",\"issuanceDate\":\"2023-01-18T17:39:11.723Z\",\"expirationDate\":\"2023-02-17T17:39:11.723Z\",\"proof\":{\"type\":\"Ed25519Signature2018\",\"creator\":\"did:SEJONG_SCS:5uMrDKwrPtn3KipERYuDAhEmHyopnEMK9PRUQYVGv3EZ\",\"created\":\"2023-01-18T08:39:12.037Z\",\"proofPurpose\":\"assertionMethod\",\"verificationMethod\":\"did:SEJONG_SCS:5uMrDKwrPtn3KipERYuDAhEmHyopnEMK9PRUQYVGv3EZ#did-owner-key\",\"proofValue\":\"eyJjcml0IjpbImI2NCJdLCJiNjQiOmZhbHNlLCJhbGciOiJFZERTQSJ9..Baox9t5ZgiueLnyHvhpVLu0MZxLPuHcw4e4Ys-IMzgIq89bNofWKmz5Y0XG7hxeDyBSrMLsRV1qwJtwpK2kLAA\"}}"
             * }
             *  VP 던지는 형식은 Json형태를 String으로 던지고 ->
             *  String 형태를 Gson의 Element형태로 만들면 가능하다.
             */
//    }
}

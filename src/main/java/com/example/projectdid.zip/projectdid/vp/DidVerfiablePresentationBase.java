package com.example.projectdid.vp;

import com.example.projectdid.vc.VCDocument;
import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * packageName   : com.example.projectdid.vp
 * fileName  : DidVpBASE
 * author    : jiseung-gu
 * date  : 2023/01/11
 * description :
 **/
public class DidVerfiablePresentationBase<T extends VCDocument> {

    @Expose(serialize = true, deserialize = true)
    @SerializedName(DidVpDocumentJsonProperties.CONTEXT)
    protected String context;

    @Expose(serialize = true, deserialize = true)
    @SerializedName(DidVpDocumentJsonProperties.ID)
    protected String id;

    @Expose(serialize = true, deserialize = true)
    @SerializedName(DidVpDocumentJsonProperties.TYPE)
    protected List<String> type;

    @Expose(serialize = true, deserialize = true)
    @SerializedName(DidVpDocumentJsonProperties.VERIFIABLECREDENTIAL)
    protected List<JsonElement> verifiableCredential;

//    @Expose(serialize = true, deserialize = true)
//    @SerializedName(DidVpDocumentJsonProperties.PROOF)
//    protected String proof;

    public DidVerfiablePresentationBase() {
        super();
        this.context = DidVpDocumentJsonProperties.CONTEXT;
        this.type = Lists.newArrayList(DidVpDocumentJsonProperties.VERIFIABLE_PRESENTATION_TYPE);
    }

    public void setContext(final String context) {
        this.context = context;
    }

    public void setId(String id) {this.id = id;}

//    public void setVerifiableCredential(String verifiableCredential) {
//        this.verifiableCredential = verifiableCredential;
//    }
//    public void addVC(final HashMap<String,JsonElement> array) {
    public void addVC(final JsonElement array) {
        System.out.println(array);
        if(this.verifiableCredential == null) {
            this.verifiableCredential = new ArrayList<>();
        }
        this.verifiableCredential.add(array);
    }
    public List<JsonElement> getVerifiableCredential() {
        return verifiableCredential;
    }
    public void addType(final String type) {
        System.out.println("type :"+type);
//        System.out.println(type.toString());
//        System.out.println(type.length());
        this.type.add(type);
    }

    //proof는 위치 미정
//    public void setProof(String proof) {
//        this.proof = proof;
//    }
}

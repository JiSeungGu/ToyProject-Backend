package com.example.projectdid.utils;

import com.google.common.collect.ImmutableList;
import org.threeten.bp.Instant;
import org.threeten.bp.format.DateTimeFormatter;


/**
 * Gson type adapter for serialization/deserialization between {@link Instant} and ISO 8601 date format.
 */
public final class Iso8601InstantTypeAdapter extends InstantTypeAdapter {

  public static final DateTimeFormatter DEFAULT_OUTPUT_FORMATTER = DateTimeFormatter.ISO_INSTANT;

  public static final ImmutableList<DateTimeFormatter> DEFAULT_INPUT_PARSERS = ImmutableList.of(
          DateTimeFormatter.ISO_INSTANT,
          DateTimeFormatter.ISO_OFFSET_DATE_TIME,
          DateTimeFormatter.ISO_DATE_TIME,
          DateTimeFormatter.ISO_LOCAL_DATE_TIME);

  private static final Iso8601InstantTypeAdapter DEFAULT_INSTANCE = new Iso8601InstantTypeAdapter();

  public Iso8601InstantTypeAdapter() {
    super(DEFAULT_OUTPUT_FORMATTER, DEFAULT_INPUT_PARSERS);
  }

  /**
   * Returns the statically defined instance constructed with the default formatter.
   *
   * @return the instance
   * @see #DEFAULT_OUTPUT_FORMATTER
   * @see #DEFAULT_INPUT_PARSERS
   */
  public static Iso8601InstantTypeAdapter getInstance() {
    return DEFAULT_INSTANCE;
  }
}

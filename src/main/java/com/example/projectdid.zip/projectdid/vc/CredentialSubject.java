package com.example.projectdid.vc;

import com.example.projectdid.utils.Iso8601InstantTypeAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import org.threeten.bp.Instant;

import java.util.LinkedHashMap;

/**
 * packageName   : com.example.projectdid.vc
 * fileName  : CredentialSubject
 * author    : jiseung-gu
 * date  : 2023/01/09
 * description : Issuer가 holder에게 VC를 전달할때 들어가는 클레임 Subject
 *               기존 Hashgraph  hedera에서는 id값을 상속받아서 구현하였지만 이번 프로젝트에서는 통일 예정
 **/
public class CredentialSubject {
                                                        //  소속    /    직위    /  이름 /  핸드폰 번호 /  재직 여부
    private static final String[] JSON_PROPERTIES_ORDER = {"type", "position", "name", "phoneno","status"};

    @Expose(serialize = true, deserialize = true)
    @SerializedName(DidVerifiableCredentialJsonProperties.ID)
    protected String id;

    @Expose
    private final String type;

    @Expose
    private final String position;

    @Expose
    private final String name;

    @Expose
    private final String phoneno;

    @Expose
    private final char status;

    public CredentialSubject(String type, String position, String name, String phoneno, char status) {
        this.type = type;
        this.position = position;
        this.name = name;
        this.phoneno = phoneno;
        this.status = status;
    }


    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public JsonElement toNormalizedJsonElement() {
        Gson gson = new GsonBuilder()
                .disableHtmlEscaping()
                .excludeFieldsWithoutExposeAnnotation()
                .registerTypeAdapter(Instant.class, Iso8601InstantTypeAdapter.getInstance())
                .create();

        // First turn to normal JSON
        JsonObject root = gson.toJsonTree(this).getAsJsonObject();
        // Then put JSON properties in ordered map
        LinkedHashMap<String, JsonElement> map = new LinkedHashMap<>();

        for (String property : JSON_PROPERTIES_ORDER) {
            if (root.has(property)) {
                map.put(property, root.get(property));
            }
        }
        // Turn map to JSON
        return gson.toJsonTree(map);
    }
}
